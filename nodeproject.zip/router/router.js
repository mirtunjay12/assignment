const express = require("express");
const router = express.Router();
const User= require("../db/userSchema");
const bodyParser = require("body-parser");

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: true }));

router.get("/signup", (req, res) => {
    res.render("signup");
  });
  
  router.get("/signin", (req, res) => {
    res.render("signin");
  });

router.post("/signup", async (req, res) => {
    console.log(req.body);
    const { name, email, phone, password, cpassword } = req.body;
  
    if (!name || !email || !phone || !password || !cpassword) {
      return res.status(422).json({ error: "Please check the details" });
    }
    try {
      const userExist = await User.findOne({ email: email });
      if (userExist) {
        return res.status(422).json({ err: "email already exist" });
      } else if (password != cpassword) {
        return res.status(422).json({ error: "Password are not matched" });
      }
    } catch (err) {
      console.log(err);
    }
    try {
      const newUser = new User({
        name,
        email,
        phone,
        password,
        cpassword,
      });
  
      const saveUser = await newUser.save();
      if (saveUser) {
        //   res.render("User", { message: "User registered " });
        //   res.status(201).json({ message: "user registered successfully" });
        res.redirect("signin");
      }
    } catch (err) {
      console.log(err);
    }
  });
  

  router.post("/signin", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "please check the data" });
    }
    try {
      const userLogin = await User.findOne({ email: email });
      console.log(userLogin);
      if (userLogin) {
        const isMatch = await (password, userLogin.password);
  
        if (!isMatch) {
          res.json({ error: "User invalid" });
        } else {
          // res.json({ Message: "user logged in successfully" });
          res.redirect("/display");
        }
      } else {
        res.json({ error: "Invalid Credentials" });
      }
    } catch (err) {
      console.log(err);
    }
  });

router.get("/display", (req, res) => {
    User.find((err, data) => {
      if (err) {
        console.log(err);
      } else {
        console.log(data);
        res.render("display", { data: data });
        // res.send(data);
      }
    }).sort({ name: 1 });
  });
  
  router.get("/show/:id", async (req, res) => {
    try {
      const _id = req.params.id;
      // console.log(_id);
      const getUser = await User.findById({ _id });
      console.log(getUser);
      // res.send(getUser);
      res.render("show", { data: getUser });
    } catch (err) {
      console.log(err);
      res.status(400).send(err);
    }
  });

  router.get("/update/:id", async (req, res) => {
    try {
      const _id = req.params.id;
      console.log(_id);
      const getUser = await User.findById({ _id });
      res.render("update", { data: getUser });
    } catch (err) {
      console.log(err);
    }
  });
   

  router.post("/update/:id", async (req, res) => {
    if (!req.body) {
      return res.status(400).send({ message: "Data to update can not be empty" });
    }
  
    try {
      const _id = req.params.id;
      const getUser = await User.findByIdAndUpdate(_id, req.body);
      console.log(getUser);
      res.redirect("/display");
    } catch (err) {
      res.redirect("update/" + _id);
      console.log(err);
      // res.status(500).send(err); // server error starts from 500
    }
  });
  
  router.get("/delete/:id", async (req, res) => {
    try {
      const _id = req.params.id;
      const getUser = await User.findByIdAndDelete(_id);
      console.log(`Data is Deleted <br> ${getUser}`);
      res.redirect("/display");
    } catch (err) {
      console.log(err);
      res.status(500).send(err); // server error starts from 500
    }
  });

router.get("/",function(req,res){
    res.send("Home");
})

module.exports = router;