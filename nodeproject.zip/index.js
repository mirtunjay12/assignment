const express = require("express");
const app = express();
const port = 8081;
const router = require("./router/router");
const connection = require("./db/connection");
const bodyParser = require("body-parser");

app.use("/",router);

app.set('view engine','ejs');
app.use(bodyParser.urlencoded({extended:true})); 

app.listen(port,()=>{console.log("server is listening...")});