const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://admin:1234@cluster0.aawp8.mongodb.net/?retryWrites=true&w=majority",{useNewUrlParser:true, useUnifiedTopology:true})
.then(()=>{console.log("Database Connected")})
.catch((err)=>{console.log(err)});